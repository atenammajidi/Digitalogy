// this beacon is used by PressLabs for metric computations on www.searchenginejournal.com
